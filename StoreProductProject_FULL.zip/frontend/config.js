const API_URL = "http://localhost:3001/products";
export default API_URL;