import React, { useState } from "react";
import API from "../config";

function AddProductForm({ reload }) {
  const [f, setF] = useState({ name:"", price:"", description:"", category:"", image:"" });

  const ch = e => setF({...f, [e.target.name]: e.target.value});

  const submit = async e => {
    e.preventDefault();
    await fetch(API, {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify(f)
    });
    reload();
  };

  return (
    <form onSubmit={submit} style={{ marginBottom:25 }}>
      <input name="name" placeholder="Name" onChange={ch} />
      <input name="price" placeholder="Price" onChange={ch} />
      <input name="description" placeholder="Description" onChange={ch} />
      <input name="category" placeholder="Category" onChange={ch} />
      <input name="image" placeholder="Image" onChange={ch} />
      <button>Add Product</button>
    </form>
  );
}

export default AddProductForm;
