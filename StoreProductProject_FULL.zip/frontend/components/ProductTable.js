function ProductTable({ products }) {
  return (
    <table border="1" width="100%" cellPadding="10">
      <thead>
        <tr><th>ID</th><th>Name</th><th>Price</th><th>Category</th></tr>
      </thead>
      <tbody>
        {products.map(p => (
          <tr key={p.id}>
            <td>{p.id}</td><td>{p.name}</td><td>${p.price}</td><td>{p.category}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
export default ProductTable;
