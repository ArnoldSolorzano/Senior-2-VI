function ProductCards({ products }) {
  return (
    <div style={{ display:"flex", gap:15, flexWrap:"wrap" }}>
      {products.map(p => (
        <div key={p.id} style={{ border:"1px solid #ccc", padding:10, width:200 }}>
          <h3>{p.name}</h3>
          <p>Price: ${p.price}</p>
          <p>{p.category}</p>
        </div>
      ))}
    </div>
  );
}
export default ProductCards;
