import React, { useEffect, useState } from "react";
import API from "./config";
import ProductTable from "./components/ProductTable";
import ProductCards from "./components/ProductCards";
import AddProductForm from "./components/AddProductForm";

function App() {
  const [products, setProducts] = useState([]);

  const loadProducts = async () => {
    const res = await fetch(API);
    const data = await res.json();
    setProducts(data);
  };

  useEffect(() => { loadProducts(); }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>Store Product Management</h1>
      <AddProductForm reload={loadProducts} />
      <h2>Table View</h2>
      <ProductTable products={products} />
      <h2>Card View</h2>
      <ProductCards products={products} />
    </div>
  );
}

export default App;
