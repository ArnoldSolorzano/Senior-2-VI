CREATE DATABASE IF NOT EXISTS productdb;
USE productdb;

CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(150),
  price DECIMAL(10,2),
  description TEXT,
  category VARCHAR(100),
  image LONGBLOB
);

INSERT INTO products (name, price, description, category, image) VALUES
('Wireless Mouse', 19.99, 'Simple wireless mouse for daily use', 'Electronics', NULL),
('Running Shoes', 49.99, 'Lightweight shoes for training', 'Sports', NULL),
('Backpack', 29.50, 'Medium-size backpack for school/travel', 'Accessories', NULL),
('Headphones', 25.00, 'Basic wired headphones with good sound', 'Electronics', NULL),
('T-shirt', 12.00, 'Comfortable cotton t-shirt', 'Clothing', NULL);
