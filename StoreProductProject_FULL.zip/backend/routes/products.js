const express = require("express");
const router = express.Router();
const db = require("../db");

router.get("/", (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

router.get("/:id", (req, res) => {
    db.query("SELECT * FROM products WHERE id = ?", [req.params.id], (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results[0]);
    });
});

router.post("/", (req, res) => {
    const p = req.body;
    db.query("INSERT INTO products SET ?", p, err => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Product added" });
    });
});

router.put("/:id", (req, res) => {
    db.query("UPDATE products SET ? WHERE id = ?", [req.body, req.params.id], err => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Product updated" });
    });
});

router.delete("/:id", (req, res) => {
    db.query("DELETE FROM products WHERE id = ?", [req.params.id], err => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Product deleted" });
    });
});

module.exports = router;
