const express = require("express");
const cors = require("cors");
const app = express();
const productsRoute = require("./routes/products");

app.use(cors());
app.use(express.json());

app.use("/products", productsRoute);

app.listen(3001, () => console.log("API running on port 3001"));
