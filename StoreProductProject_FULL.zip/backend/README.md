# Backend API
How to run:
1. npm install
2. npm start

Endpoints:
GET /products
GET /products/:id
POST /products
PUT /products/:id
DELETE /products/:id
